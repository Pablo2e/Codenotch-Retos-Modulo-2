class Movie {
    //creo el constructor
    constructor(title, releaseYear, nationality, genre, foto, language, plataform, isMCU, mainCharacterName, actors, director, writer, producer, distributor ) {
        this.title = title;
        this.releaseYear = releaseYear;
        this.nationality = nationality;
        this.genre = genre;
        this.foto = foto;
        this.language= language
        this.plataform= plataform
        this.isMCU= isMCU
        this.mainCharacterName= mainCharacterName
        this.actors= actors
        this.director= director
        this.writer= writer
        this.producer= producer
        this.distributor= distributor
    /* public actors: Professional[]
    public director: Professional
    public writer: Professional  */
    }
    getFoto(){
        return (this.foto)
    }
    printActors(){
        let actS=""
        for (let i in this.actors){
            actS+= this.actors[i].print()+"\n"
        }
        return (actS)
    }
    print() {
        return("Titulo de la pelicula: "+ this.title +"\n"+
        "Año de lanzamiento: "+ this.releaseYear +"\n"+
        "Nacionalidad de la pelicula: "+ this.nationality +"\n"+
        "Genero de la pelicula: "+ this.genre +"\n"+
        "Link a la foto de caratula: "+ this.foto +"\n"+
        "Idioma de la pelicula: " +this.language +"\n"+
        "Plataforma donde se emite: "+ this.plataform +"\n"+
        "¿Es del Universo Marvel?: "+ this.isMCU +"\n"+
        "Nombre del/la protagonista: "+ this.mainCharacterName+"\n"+
        "Actores: "+ this.printActors() +"\n"+
        "Director: "+ this.director.name +"\n"+
        "Escritor: "+ this.writer.print()+"\n"+
        "Nombre del productor: "+ this.producer+ "\n"+
        "Distribuidora: "+ this.distributor +"\n");
    }   
}

module.exports = Movie