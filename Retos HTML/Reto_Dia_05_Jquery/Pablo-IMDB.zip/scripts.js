
datosSev=()=>{
    //alert(seven.print())
    alert(imdb.print())
}
datosSil=()=>{
    //alert(lamb.print())
    alert(imdb.getMovie("EL silencio de los corderos").print())
}
datosMat=()=>{
    alert(matilda.print())
}

agregarPeli=()=>{
    let titulo= $("#inputTitulo").val()
    let anio= $("#inputAnio").val()
    let nacionalidad= $("#inputNacionalidad").val()
    let genero= $("#inputGenero").val()
    let foto= $("#inputFoto").val()
    let language= $("#inputIdioma").val()
    let plataform= $("#inputPlataforma").val()
    let isMCU= $("#inputIsMcu").val()
    let mainCharacterName= $("#inputNombreProta").val()
    let producer= $("#inputProductor").val()
    let distributor= $("#inputDistribuidor").val()
    alert("Has agregado: "+"\n"+
    "Titulo de la pelicula: "+titulo+"\n"+
    "Año de lanzamiento: "+anio+"\n"+
    "Nacionalidad de la pelicula: "+nacionalidad+"\n"+
    "Genero de la pelicula: "+genero+"\n"+
    "Link a la foto de caratula: "+foto+"\n"+
    "Idioma de la pelicula: "+language+"\n"+
    "Plataforma donde se emite: "+plataform+"\n"+
    "¿Es del Universo Marvel?: "+isMCU+"\n"+
    "Nombre del/la protagonista: "+mainCharacterName+"\n"+
    "Nombre del productor: "+producer+"\n"+
    "Distribuidora: "+distributor+"\n")
}
agregarActor=()=>{
    let name= $("#inputName").val()
    let age= $("#inputEdad").val()
    let genre= $("#inputGeneroA").val()
    let weight= $("#inputPeso").val()
    let height= $("#inputAltura").val()
    let hairColor= $("#inputPelo").val()
    let eyeColor= $("#inputOjos").val()
    let race= $("#inputRaza").val()
    let isRetired= $("#inputRetirado").val()
    let nationality= $("#inputNacionalidadA").val()
    let oscarsNumber= $("#inputOscar").val()
    let profession= $("#inputProfesion").val()
    let foto= $("#inputFotoA").val()
    alert("Has agregado: "+"\n"+
    "Nombre actor/actriz: "+name+"\n"+
    "Edad: "+age+"\n"+
    "Genero: "+genre+"\n"+
    "Peso: "+weight+"\n"+
    "Altura: "+height+"\n"+
    "Color de pelo: "+hairColor+"\n"+
    "Color de ojos: "+eyeColor+"\n"+
    "Raza: "+race+"\n"+
    "¿Esta retirado/a? Si o No: "+isRetired+"\n"+
    "Nacionalidad: "+nationality+"\n"+
    "Oscars ganados: "+oscarsNumber+"\n"+
    "Profesión: "+profession+"\n"+
    "Link a su foto de cara: "+foto+"\n"
    )
}
agregarDirector=()=>{
    let name= $("#inputNameD").val()
    let age= $("#inputEdadD").val()
    let genre= $("#inputGeneroD").val()
    let weight= $("#inputPesoD").val()
    let height= $("#inputAlturaD").val()
    let hairColor= $("#inputPeloD").val()
    let eyeColor= $("#inputOjosD").val()
    let race= $("#inputRazaD").val()
    let isRetired= $("#inputRetiradoD").val()
    let nationality= $("#inputNacionalidadD").val()
    let oscarsNumber= $("#inputOscarD").val()
    let profession= $("#inputProfesionD").val()
    let foto= $("#inputFotoD").val()
    alert("Has agregado: "+"\n"+
    "Nombre Director/a: "+name+"\n"+
    "Edad: "+age+"\n"+
    "Genero: "+genre+"\n"+
    "Peso: "+weight+"\n"+
    "Altura: "+height+"\n"+
    "Color de pelo: "+hairColor+"\n"+
    "Color de ojos: "+eyeColor+"\n"+
    "Raza: "+race+"\n"+
    "¿Esta retirado/a? Si o No: "+isRetired+"\n"+
    "Nacionalidad: "+nationality+"\n"+
    "Oscars ganados: "+oscarsNumber+"\n"+
    "Profesión: "+profession+"\n"+
    "Link a su foto de cara: "+foto+"\n"
    )
}
agregarProductor=()=>{
    let name= $("#inputNameP").val()
    let age= $("#inputEdadP").val()
    let genre= $("#inputGeneroP").val()
    let weight= $("#inputPesoP").val()
    let height= $("#inputAlturaP").val()
    let hairColor= $("#inputPeloP").val()
    let eyeColor= $("#inputOjosP").val()
    let race= $("#inputRazaP").val()
    let isRetired= $("#inputRetiradoP").val()
    let nationality= $("#inputNacionalidadP").val()
    let oscarsNumber= $("#inputOscarP").val()
    let profession= $("#inputProfesionP").val()
    let foto= $("#inputFotoP").val()
    alert("Has agregado: "+"\n"+
    "Nombre Productor/a: "+name+"\n"+
    "Edad: "+age+"\n"+
    "Genero: "+genre+"\n"+
    "Peso: "+weight+"\n"+
    "Altura: "+height+"\n"+
    "Color de pelo: "+hairColor+"\n"+
    "Color de ojos: "+eyeColor+"\n"+
    "Raza: "+race+"\n"+
    "¿Esta retirado/a? Si o No: "+isRetired+"\n"+
    "Nacionalidad: "+nationality+"\n"+
    "Oscars ganados: "+oscarsNumber+"\n"+
    "Profesión: "+profession+"\n"+
    "Link a su foto de cara: "+foto+"\n"
    )
}


     


